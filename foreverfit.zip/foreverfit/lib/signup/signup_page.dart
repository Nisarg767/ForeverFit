import 'package:flutter/material.dart';
import 'package:foreverfit/resource/resource.dart';
import 'package:foreverfit/screen/home/home_page.dart';
import 'package:toast/toast.dart';


class SignUpScreen extends StatefulWidget {
  @override
  _SignUpScreenState createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {

  final _formKey = GlobalKey<FormState>();

  FocusNode focusEmail,focusPass,focusFname,focusLname,focusMob;
  bool passVisible = false;
  String email,password,fname,lname,mob;
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  TextEditingController fnameController = TextEditingController();
  TextEditingController lnameController = TextEditingController();
  TextEditingController mobController = TextEditingController();


  bool isEmail(String em) {

    String p = r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$';

    RegExp regExp = new RegExp(p);

    return regExp.hasMatch(em);
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    focusFname = FocusNode();
    focusLname = FocusNode();
    focusEmail = FocusNode();
    focusPass = FocusNode();
    focusMob = FocusNode();

  }

  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
    focusFname.dispose();
    focusLname.dispose();
    focusEmail.dispose();
    focusPass.dispose();
    focusMob.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: SingleChildScrollView(

          child: Padding(
            padding: const EdgeInsets.all(25.0),
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  SizedBox(
                    height: 100.0,
                    child: Image.asset(
                      "image/splash/img_splash_logo.jpg",
                      fit: BoxFit.contain,
                    ),
                  ),
                  SizedBox(height: 40.0),

                  TextFormField(
                    controller: fnameController,
                    onSaved: (String val) {

                      fname = val;
                    },
                    focusNode: focusFname,

                    onFieldSubmitted: (value) {
                      focusFname.unfocus();
                      FocusScope.of(context).requestFocus(focusLname);

                    },
                    style: TextStyle(
                        fontFamily: "Jaapokki",
                        fontSize: 16.0,
                        color: Colors.black),

//
                    decoration: new InputDecoration(
                      labelText: "First Name",
                      labelStyle: Resource.style.homeItemTitle3(),
                      fillColor: Colors.white,
                      prefixIcon: Icon(Icons.person,color:Colors.black ),

                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.black38, width: 5.0),
                        borderRadius: new BorderRadius.circular(32.0),
                      ),

                      //fillColor: Colors.green
                    ),
                    textInputAction: TextInputAction.next,
                    keyboardAppearance: Brightness.light,
                    keyboardType: TextInputType.text,
                  ),
                  // emailField,
                  SizedBox(height: 25.0),

                  TextFormField(
                    controller: lnameController,
                    onSaved: (String val) {

                      lname = val;
                    },
                    focusNode: focusLname,

                    onFieldSubmitted: (value) {
                      focusLname.unfocus();
                      FocusScope.of(context).requestFocus(focusEmail);

                    },
                    style: TextStyle(
                        fontFamily: "Jaapokki",
                        fontSize: 16.0,
                        color: Colors.black),

//
                    decoration: new InputDecoration(
                      labelText: "Last Name",
                      labelStyle: Resource.style.homeItemTitle3(),
                      fillColor: Colors.white,
                      prefixIcon: Icon(Icons.person,color: Colors.black),

                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.black38, width: 5.0),
                        borderRadius: new BorderRadius.circular(32.0),
                      ),

                      //fillColor: Colors.green
                    ),
                    textInputAction: TextInputAction.next,
                    keyboardAppearance: Brightness.light,
                    keyboardType: TextInputType.text,
                  ),
                  // emailField,
                  SizedBox(height: 25.0),


                  TextFormField(
                    controller: emailController,
                    onSaved: (String val) {

                      email = val;
                    },
                    focusNode: focusEmail,

                    onFieldSubmitted: (value) {
                      focusEmail.unfocus();
                      FocusScope.of(context).requestFocus(focusPass);

                    },
                    style: TextStyle(
                        fontFamily: "Jaapokki",
                        fontSize: 16.0,
                        color: Colors.black),

//
                    decoration: new InputDecoration(
                      labelText: "Email",
                      labelStyle: Resource.style.homeItemTitle3(),
                      fillColor: Colors.white,
                      prefixIcon: Icon(Icons.email,color: Colors.black),

                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.black38, width: 5.0),
                        borderRadius: new BorderRadius.circular(32.0),
                      ),

                      //fillColor: Colors.green
                    ),
                    textInputAction: TextInputAction.next,
                    keyboardAppearance: Brightness.light,
                    keyboardType: TextInputType.emailAddress,
                  ),
                  // emailField,
                  SizedBox(height: 25.0),

                  TextFormField(
                    controller: passwordController,
                    onSaved: (String val) {
                      password = val;
                    },
                    obscureText: !passVisible,
                    focusNode: focusPass,
                    onFieldSubmitted: (value) {
                      focusPass.unfocus();
                      FocusScope.of(context).requestFocus(focusMob);
                    },
                    style: TextStyle(
                        fontFamily: "Jaapokki",
                        fontSize: 16.0,
                        color: Colors.black),

                    decoration: new InputDecoration(
                      labelText: "Password",
                      labelStyle: Resource.style.homeItemTitle3(),
                      fillColor: Colors.white,
                      prefixIcon: Icon(Icons.lock,color: Colors.black),
                      suffixIcon: GestureDetector(
                        onTap: () {
                          setState(() {
                            passVisible = !passVisible;
                          });
                        },


                        child: passVisible == false ? Icon(Icons.visibility_off,color:Colors.black) : Icon(Icons.visibility,color:Colors.black),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.black38, width: 5.0),
                        borderRadius: new BorderRadius.circular(32.0),
                      ),    //fillColor: Colors.green
                    ),
                    textInputAction: TextInputAction.next,
                    keyboardAppearance: Brightness.light,
                    keyboardType: TextInputType.text,

                  ),
                  //  passwordField,
                  SizedBox(
                    height: 25.0,
                  ),

                  TextFormField(
                    controller: mobController,
                    onSaved: (String val) {

                      mob = val;
                    },
                    focusNode: focusMob,
                    style: TextStyle(
                        fontFamily: "Jaapokki",
                        fontSize: 16.0,
                        color: Colors.black),

//
                    decoration: new InputDecoration(
                      labelText: "Mobile Number",
                      labelStyle: Resource.style.homeItemTitle3(),
                      fillColor: Colors.white,
                      prefixIcon: Icon(Icons.phone,color:Colors.black),

                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.black38, width: 5.0),
                        borderRadius: new BorderRadius.circular(32.0),
                      ),     //fillColor: Colors.green
                    ),
                    textInputAction: TextInputAction.go,
                    keyboardAppearance: Brightness.light,
                    keyboardType: TextInputType.number,
                  ),
                  // emailField,
                  SizedBox(height: 35.0),

                  Material(
                    elevation: 5.0,
                    borderRadius: BorderRadius.circular(32.0),
                    color: Colors.pink,
                    child: MaterialButton(
                      minWidth: MediaQuery
                          .of(context)
                          .size
                          .width,
                      padding: EdgeInsets.fromLTRB(20.0, 15.0, 20.0, 15.0),
                      onPressed: () {
                        focusMob.unfocus();

                        if(emailController.text.isEmpty == true && passwordController.text.isEmpty == true
                            && fnameController.text.isEmpty == true && lnameController.text.isEmpty == true
                            && mobController.text.isEmpty == true){

                          Toast.show("Please enter all details.", context,duration: Toast.LENGTH_LONG,gravity: Toast.BOTTOM);
                        }
                        else if(!isEmail(emailController.text)) {
                          Toast.show("Please enter a valid email.", context,duration: Toast.LENGTH_LONG,gravity: Toast.BOTTOM);
                        }
                        else if(emailController.text.isEmpty == true && passwordController.text.isEmpty == false
                            && fnameController.text.isEmpty == false && lnameController.text.isEmpty == false
                            && mobController.text.isEmpty == false){
                          Toast.show("Please enter an email address.", context,duration: Toast.LENGTH_LONG,gravity: Toast.BOTTOM);
                        }
                        else if(emailController.text.isEmpty == false && passwordController.text.isEmpty == false
                            && fnameController.text.isEmpty == true && lnameController.text.isEmpty == false
                            && mobController.text.isEmpty == false){
                          Toast.show("Please enter First Name.", context,duration: Toast.LENGTH_LONG,gravity: Toast.BOTTOM);
                        }
                        else if(emailController.text.isEmpty == false && passwordController.text.isEmpty == false
                            && fnameController.text.isEmpty == false && lnameController.text.isEmpty == true
                            && mobController.text.isEmpty == false){
                          Toast.show("Please enter Last Name.", context,duration: Toast.LENGTH_LONG,gravity: Toast.BOTTOM);
                        }
                        else if(emailController.text.isEmpty == false && passwordController.text.isEmpty == true
                            && fnameController.text.isEmpty == false && lnameController.text.isEmpty == false
                            && mobController.text.isEmpty == false){
                          Toast.show("Please enter Password.", context,duration: Toast.LENGTH_LONG,gravity: Toast.BOTTOM);
                        }
                        else if(emailController.text.isEmpty == false && passwordController.text.isEmpty == false
                            && fnameController.text.isEmpty == false && lnameController.text.isEmpty == false
                            && mobController.text.isEmpty == true){
                          Toast.show("Please enter Mobile Number.", context,duration: Toast.LENGTH_LONG,gravity: Toast.BOTTOM);
                        }
                        else if(emailController.text.isEmpty == true || passwordController.text.isEmpty == true
                            || fnameController.text.isEmpty == true || lnameController.text.isEmpty == true
                            || mobController.text.isEmpty == true){

                          Toast.show("Please enter all details.", context,duration: Toast.LENGTH_LONG,gravity: Toast.BOTTOM);
                        }
                        else
                        {
                          Toast.show("Sign Up Successful.", context,duration: Toast.LENGTH_LONG,gravity: Toast.BOTTOM);
                          Navigator.of(context).push(MaterialPageRoute(
                              builder: (BuildContext context) => HomePage() ));
                        }

                      },
                      child: Text("Sign Up",
                          style: TextStyle(color: Colors.white),
                          textAlign: TextAlign.center
                      ),
                    ),
                  ),
                  //  loginButon,
                  SizedBox(
                    height: 15.0,
                  ),

                  GestureDetector(

                    onTap: () {

                      Navigator.of(context).pop();
                    },
                    child:  Text("Already have an Account? Login",
                        style: TextStyle(color: Colors.black,fontWeight: FontWeight.bold,fontSize: 14.0,decoration: TextDecoration.underline),
                        textAlign: TextAlign.center
                    ),
                  ),
                  SizedBox(
                    height: 25.0,
                  ),
                ],
              ),

            ),

          ),


        ),

      ),
    );
  }

}
