import 'package:flutter/material.dart';
import 'package:foreverfit/resource/resource.dart';
import 'package:foreverfit/screen/home/home_page.dart';
import 'package:foreverfit/signup/signup_page.dart';
import 'package:toast/toast.dart';


class LoginScreen extends StatefulWidget {
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {

  final _formKey = GlobalKey<FormState>();

  FocusNode focusEmail,focusPass;
  bool passVisible = false;
  String email,password;
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();


  bool isEmail(String em) {

    String p = r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$';

    RegExp regExp = new RegExp(p);

    return regExp.hasMatch(em);
  }
  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    focusEmail = FocusNode();
    focusPass = FocusNode();
  }
  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
    focusEmail.dispose();
    focusPass.dispose();
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: SingleChildScrollView(

          child: Padding(
            padding: const EdgeInsets.all(25.0),
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  SizedBox(

                    height: 155.0,
                    child: Image.asset(

                      "image/splash/img_splash_logo.jpg",
                    ),
                  ),
                  SizedBox(height: 40.0),
                  TextFormField(
                    controller: emailController,
                    onSaved: (String val) {

                      email = val;
                    },
                    focusNode: focusEmail,

                    onFieldSubmitted: (value) {
                      focusEmail.unfocus();
                      FocusScope.of(context).requestFocus(focusPass);

                    },
                    style: TextStyle(
                        fontFamily: "Jaapokki",
                        fontSize: 16.0,
                        color: Colors.black),

//
                    decoration: new InputDecoration(
                      labelText: "Email",
                      labelStyle: Resource.style.homeItemTitle3(),
                      prefixIcon: Icon(Icons.email,color:Colors.black),
                       fillColor: Colors.black38,
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.black38, width: 5.0),
                        borderRadius: new BorderRadius.circular(32.0),
                      ),
                    ),
                  ),
                  // emailField,
                  SizedBox(height: 25.0),

                  TextFormField(

                    controller: passwordController,
                    onSaved: (String val) {
                      password = val;
                    },
                    obscureText: !passVisible,
                    focusNode: focusPass,
                    style: TextStyle(
                        fontFamily: "Jaapokki",
                        fontSize: 16.0,
                        color: Colors.black),

                    decoration: new InputDecoration(
                      labelText: "Password",
                      labelStyle: Resource.style.homeItemTitle3(),

                      fillColor: Colors.black,
                      prefixIcon: Icon(Icons.lock,color:Colors.black),
                      suffixIcon: GestureDetector(
                        onTap: () {
                          setState(() {
                            passVisible = !passVisible;


                          });
                        },


                        child: passVisible == false ? Icon(Icons.visibility_off,color: Colors.black,) : Icon(Icons.visibility,color: Colors.black,),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.black38, width: 5.0),
                        borderRadius: new BorderRadius.circular(32.0),
                      ),
                      //fillColor: Colors.green
                    ),
                  ),
                  //  passwordField,
                  SizedBox(
                    height: 35.0,
                  ),

                  Material(
                    elevation: 5.0,
                    borderRadius: BorderRadius.circular(32.0),
                    color: Colors.pink,
                    child: MaterialButton(
                      minWidth: MediaQuery
                          .of(context)
                          .size
                          .width,
                      padding: EdgeInsets.fromLTRB(20.0, 15.0, 20.0, 15.0),
                      onPressed: () {
                        focusPass.unfocus();
                        if(emailController.text.isEmpty == true && passwordController.text.isEmpty == true){

                          Toast.show("Please enter valid email and password.", context,duration: Toast.LENGTH_LONG,gravity: Toast.BOTTOM);
                        }
                        else if(!isEmail(emailController.text)) {
                          Toast.show("Please enter valid email.", context,duration: Toast.LENGTH_LONG,gravity: Toast.BOTTOM);

                        }
                        else if(emailController.text.isEmpty == true && passwordController.text.isEmpty == false){

                          Toast.show("Please enter valid email.", context,duration: Toast.LENGTH_LONG,gravity: Toast.BOTTOM);
                        }
                        else if(emailController.text.isEmpty == false && passwordController.text.isEmpty == true){

                          Toast.show("Please enter valid password.", context,duration: Toast.LENGTH_LONG,gravity: Toast.BOTTOM);
                        }
                        else
                        {


                          Toast.show("Login Successful.", context,duration: Toast.LENGTH_LONG,gravity: Toast.BOTTOM);

                        }
                      },
                      child: Text("Login",
                          style: TextStyle(color: Colors.white),
                          textAlign: TextAlign.center
                      ),
                    ),
                  ),
                  //  loginButon,
                  SizedBox(
                    height: 15.0,
                  ),

                  GestureDetector(

                    onTap: () {

                      Navigator.of(context).push(MaterialPageRoute(
                          builder: (BuildContext context) => SignUpScreen()));

                    },
                    child:  Text("Create a new Account? Sign Up",
                        style: TextStyle(color: Colors.black,fontWeight: FontWeight.bold,fontSize: 14.0,decoration: TextDecoration.underline),
                        textAlign: TextAlign.center
                    ),
                  ),

                  Padding(
                    padding: EdgeInsets.only(top: 10.0),
                    child: FlatButton(
                        onPressed: () {
                          Navigator.of(context).pushReplacement(MaterialPageRoute(
                              builder: (BuildContext context) => HomePage()));

                        },
                        child: Text(
                          "Skip SignIn?",
                          style: TextStyle(
                              decoration: TextDecoration.underline,
                              color: Colors.black,
                              fontSize: 16.0,
                              fontFamily: "Jaapokki"),
                        )),
                  ),


                  SizedBox(
                    height: 25.0,
                  ),
                ],
              ),

            ),

          ),


        ),

      ),
    );
  }

}
