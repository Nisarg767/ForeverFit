import 'package:flutter/material.dart';
import 'package:foreverfit/screen/app.dart';

void main() => runApp(App());
