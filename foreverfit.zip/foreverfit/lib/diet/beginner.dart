import 'package:flutter/material.dart';
import 'package:foreverfit/resource/resource.dart';
import 'package:foreverfit/resource/route.dart';

class Beginner extends StatefulWidget {
  @override
  _Beginner createState() => _Beginner();
}

class _Beginner extends State<Beginner> {


  @override
  Widget build(BuildContext context) {
    return Scaffold(
    );
  }
}
