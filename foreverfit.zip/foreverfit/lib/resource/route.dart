import 'package:flutter/cupertino.dart';

class RoutePath {
  static const String home2="/home";
  static const String splash = "/";
  static const String onBoarding = "/on-boarding";
  static const String home = "/home";
  static const String healthTipDetail = "/health-tip-detail";
  static const String exerciseGroup = "/excercuse-group";
  static const String exerciseGroup2 = "/excercuse-group";
  static const String exerciseDetail = "/excercuse-detail";
  static const String trainerDetail = "/trainer-detail";
  static const String trainerDetail2 = "/trainer-detail2";
  static const String welcome = "/welcome-screen";
  static const String shoulder="/shoulder";
  static const String challengedetail="/challengesdetail";
  static const String exercisedetail="/exercisedetail";
  static const String shoulderdetail="/shoulderdetail";
  static const String backdetail="/backdetail";
  static const String bicepsdetail="/bicepsdetail";
  static const String tricepsdetail="/tricepsdetail";
  static const String absdetail="/absdetail";
  static const String legsdetail="/legsdetail";
  static const String calfsdetail="/calfsdetail";

}
