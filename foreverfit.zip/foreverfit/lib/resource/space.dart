class Space {
  double small = 2;
  double xSmall = 4;
  double xxSmall = 6;
  double medium = 8;
  double xMedium = 10;
  double xxMedium = 12;
  double large = 16;
  double xxLarge = 18;
  double huge = 24;
  double xHuge = 28;
  double xxHuge = 32;
  double big = 48;
  double xBig = 64;
  double xxBig = 72;
}
